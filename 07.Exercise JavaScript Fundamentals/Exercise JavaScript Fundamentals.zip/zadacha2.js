function multiplyNumbers(numbers) {
    return Number(numbers[0]) * Number(numbers[1]);
}

let numbers = ['2', '3'];
console.log(multiplyNubers(numbers));