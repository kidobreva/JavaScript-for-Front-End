let number = 5;
for (let i = number; i > 0; i--) {
    console.log(i);
}
