let number = 5;
for (let i = 1; i <= number; i++) {
    console.log(i);
}


