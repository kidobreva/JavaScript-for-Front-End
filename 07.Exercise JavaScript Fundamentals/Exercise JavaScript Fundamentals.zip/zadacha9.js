let number = 5;
let numbers = [];

for (let i = 0; i <= number; i++) {
    let index = ['0', '3', '4'];
    let value = ['3', '-1', '2'];
}