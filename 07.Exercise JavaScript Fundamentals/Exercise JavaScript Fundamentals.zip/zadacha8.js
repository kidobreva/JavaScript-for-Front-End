let numbers = ['5', '5.5', '24', '-3'];

for (let i = numbers.length; i >= 0; i--) {
    console.log(numbers[i]);
}