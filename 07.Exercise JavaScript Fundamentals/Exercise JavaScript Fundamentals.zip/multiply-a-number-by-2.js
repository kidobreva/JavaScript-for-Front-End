function multiplyNumber(number) {
    let finalNumber = Number(number);

    return number * 2;
}

let numbers = ['3', '5', '7', '8', '9'];

console.log(multiplyNumber(numbers[0]));

/*for (let number of numbers) {
    console.log(multiplyNumber(number));
}*/